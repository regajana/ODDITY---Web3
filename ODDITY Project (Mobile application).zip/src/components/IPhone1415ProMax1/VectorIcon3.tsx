import { memo, SVGProps } from 'react';

const VectorIcon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 58 30' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M15.08 1.13985C26.68 5.76113 31.32 24.2462 42.92 28.8675C54.52 33.4888 58 23.0909 58 15.0037C58 6.91645 54.52 -3.48143 42.92 1.13985C31.32 5.76113 26.68 24.2462 15.08 28.8675C3.48 33.4888 0 23.0909 0 15.0037C0 6.91645 3.48 -3.48143 15.08 1.13985Z'
      stroke='#FC0000'
      strokeWidth={4}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(VectorIcon3);
export { Memo as VectorIcon3 };
