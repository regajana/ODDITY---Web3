import { memo, SVGProps } from 'react';

const Polygon6Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 38 29' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M19 0L35.4545 21.75H2.54552L19 0Z' fill='black' />
  </svg>
);

const Memo = memo(Polygon6Icon);
export { Memo as Polygon6Icon };
