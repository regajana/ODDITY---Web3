import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import classes from './Component5_Property1Frame16.module.css';
import { Polygon3Icon } from './Polygon3Icon.js';
import { Polygon4Icon } from './Polygon4Icon.js';
import { Polygon5Icon } from './Polygon5Icon.js';
import { Polygon6Icon } from './Polygon6Icon.js';

interface Props {
  className?: string;
  classes?: {
    root?: string;
  };
}
/* @figmaId 850:120 */
export const Component5_Property1Frame16: FC<Props> = memo(function Component5_Property1Frame16(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={classes.cOMMUNITY}>COMMUNITY</div>
      <div className={classes.cOMMUNITY2}>COMMUNITY</div>
      <div className={classes.cOMMUNITY3}>COMMUNITY</div>
      <div className={classes.cOMMUNITY4}>COMMUNITY</div>
      <div className={classes.polygon3}>
        <Polygon3Icon className={classes.icon} />
      </div>
      <div className={classes.polygon4}>
        <Polygon4Icon className={classes.icon2} />
      </div>
      <div className={classes.polygon5}>
        <Polygon5Icon className={classes.icon3} />
      </div>
      <div className={classes.polygon6}>
        <Polygon6Icon className={classes.icon4} />
      </div>
    </div>
  );
});
