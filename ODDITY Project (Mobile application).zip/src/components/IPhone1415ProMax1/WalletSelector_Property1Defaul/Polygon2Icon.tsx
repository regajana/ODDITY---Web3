import { memo, SVGProps } from 'react';

const Polygon2Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 29 14' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M7.45058e-07 0.499999L14.2899 13.5L29 0.499999' stroke='black' strokeWidth={2} />
  </svg>
);

const Memo = memo(Polygon2Icon);
export { Memo as Polygon2Icon };
