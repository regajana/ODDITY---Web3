import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import { Polygon2Icon } from './Polygon2Icon.js';
import classes from './WalletSelector_Property1Defaul.module.css';

interface Props {
  className?: string;
  classes?: {
    frame5?: string;
    root?: string;
  };
  swap?: {
    polygon2?: ReactNode;
  };
  text?: {
    select?: ReactNode;
  };
}
/* @figmaId 691:54 */
export const WalletSelector_Property1Defaul: FC<Props> = memo(function WalletSelector_Property1Defaul(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={`${props.classes?.frame5 || ''} ${classes.frame5}`}>
        {props.text?.select != null ? props.text?.select : <div className={classes.select}>Select</div>}
        <div className={classes.polygon2}>{props.swap?.polygon2 || <Polygon2Icon className={classes.icon} />}</div>
      </div>
    </div>
  );
});
