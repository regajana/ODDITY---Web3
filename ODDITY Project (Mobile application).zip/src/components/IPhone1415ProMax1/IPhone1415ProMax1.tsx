import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { AltsAdidasLogo2Icon } from './AltsAdidasLogo2Icon.js';
import { Component5_Property1Frame16 } from './Component5_Property1Frame16/Component5_Property1Frame16.js';
import { Component6 } from './Component6/Component6.js';
import { Ellipse12Icon } from './Ellipse12Icon.js';
import { Ellipse13Icon } from './Ellipse13Icon.js';
import { Ellipse14Icon } from './Ellipse14Icon.js';
import classes from './IPhone1415ProMax1.module.css';
import { Polygon2Icon } from './Polygon2Icon.js';
import { VectorIcon2 } from './VectorIcon2.js';
import { VectorIcon3 } from './VectorIcon3.js';
import { VectorIcon } from './VectorIcon.js';
import { WalletSelector_Property1Defaul } from './WalletSelector_Property1Defaul/WalletSelector_Property1Defaul.js';

interface Props {
  className?: string;
}
/* @figmaId 738:39 */
export const IPhone1415ProMax1: FC<Props> = memo(function IPhone1415ProMax1(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.x}>X</div>
      <div className={classes.metaverseBlogImageGmoney_22182}></div>
      <div className={classes.mETAVERSE}>METAVERSE </div>
      <div className={classes.x2}>X</div>
      <div className={classes.cOLLABSYNERGISECONVERSE}>COLLAB . SYNERGISE . CONVERSE</div>
      <div className={classes.community}>Community</div>
      <div className={classes.product}>Product</div>
      <div className={classes.about}>About</div>
      <div className={classes.frame12}>
        <div className={classes.frame11}>
          <div className={classes.rectangle15}></div>
        </div>
        <div className={classes.search}>Search </div>
        <div className={classes.vector}>
          <VectorIcon className={classes.icon2} />
        </div>
      </div>
      <div className={classes.oDDITY}>ODDITY</div>
      <div className={classes.ellipse12}>
        <Ellipse12Icon className={classes.icon3} />
      </div>
      <div className={classes.ellipse13}>
        <Ellipse13Icon className={classes.icon4} />
      </div>
      <div className={classes.ellipse14}>
        <Ellipse14Icon className={classes.icon5} />
      </div>
      <div className={classes.oDDITY2}>ODDITY</div>
      <div className={classes.oDDITY3}>ODDITY</div>
      <div className={classes.tHEPRODUCT}>THE PRODUCT.</div>
      <div className={classes.adidasGif2}></div>
      <div className={classes.rectangle11}></div>
      <div className={classes.rectangle16}></div>
      <div className={classes.rectangle12}></div>
      <div className={classes.aLTS}>ALTS</div>
      <div className={classes.vector2}>
        <VectorIcon2 className={classes.icon6} />
      </div>
      <div className={classes.collectAdidas2}></div>
      <div className={classes.oDDITY4}>ODDITY</div>
      <div className={classes.x3}>X</div>
      <div className={classes.infinity2}></div>
      <div className={classes.mETAVERSE2}>METAVERSE</div>
      <div className={classes.vector3}>
        <VectorIcon3 className={classes.icon7} />
      </div>
      <div className={classes.wHATISALTSBYADIDASALTsIsAdidas}>
        <div className={classes.textBlock}>WHAT IS ALTS BY ADIDAS?</div>
        <div className={classes.textBlock2}>
          <p className={classes.labelWrapper}>
            <span className={classes.label}>
              ALTs is adidas genesis project enabled via blockchain technology It is your access pass to a range of
              different benefits powered by adidas:
            </span>
          </p>
        </div>
        <div className={classes.textBlock3}>
          <p></p>
        </div>
        <div className={classes.textBlock4}>- early access to physical and virtual product</div>
        <div className={classes.textBlock5}>- access to tickets for events and experiences</div>
        <div className={classes.textBlock6}>- a stake in the ALTs ecosystem</div>
      </div>
      <div className={classes.aLTSAdidasLogo2}>
        <AltsAdidasLogo2Icon className={classes.icon8} />
      </div>
      <div className={classes.altsMe2}></div>
      <div className={classes.cRETOR}>CRE TOR.</div>
      <div className={classes.x4}>X</div>
      <div className={classes.jANARDHANREGA}>JANARDHAN REGA</div>
      <div className={classes.helloIMJanardhanRegaAPassionat}>
        <div className={classes.textBlock7}>Hello! I&#39;m Janardhan Rega, </div>
        <div className={classes.textBlock8}>
          a passionate UI/UX designer with a keen interest in shaping the digital landscapes of tomorrow. My journey
          into the world of design began with a curiosity for creating seamless and intuitive user experiences that
          blend functionality with aesthetic appeal.
        </div>
      </div>
      <div className={classes.figmaMe2}></div>
      <div className={classes.signUp}>Sign Up</div>
      <div className={classes.username}>Username:</div>
      <div className={classes.rectangle14}></div>
      <div className={classes.rectangle152}></div>
      <div className={classes.password}>Password:</div>
      <div className={classes.wallet}>Wallet:</div>
      <WalletSelector_Property1Defaul
        className={classes.walletSelector}
        classes={{ frame5: classes.frame5 }}
        swap={{
          polygon2: <Polygon2Icon className={classes.icon} />,
        }}
        text={{
          select: <div className={classes.select}>Select</div>,
        }}
      />
      <Component6 />
      <div className={classes.oDDITY5}>ODD ITY</div>
      <div className={classes.x5}>X</div>
      <div className={classes.createdDevelopedByJanardhanReg}>
        <div className={classes.textBlock9}>Created &amp; Developed by</div>
        <div className={classes.textBlock10}>
          <p className={classes.labelWrapper2}></p>
        </div>
        <div className={classes.textBlock11}>
          <p></p>
        </div>
        <div className={classes.textBlock12}>
          <p></p>
        </div>
        <div className={classes.textBlock13}>
          <p className={classes.labelWrapper3}>
            <span className={classes.label2}>Janardhan Rega</span>
          </p>
        </div>
      </div>
      <Component5_Property1Frame16 className={classes.component5} />
      <div className={classes.x6}>X</div>
      <div className={classes.sYNERGISE}>SYNERGISE</div>
      <div className={classes.adidasNftVoguebusAdidasNftDec2}></div>
      <div className={classes.metaverseBlogImagePunksComics_}></div>
      <div className={classes.welcomeToOddityYourPremierDest}>
        Welcome to Oddity, your premier destination for exploring the cutting-edge realms of Web3, NFTs, and beyond.
        Here at Oddity, we delve deep into the dynamic intersection of technology and creativity, offering a
        comprehensive resource hub where enthusiasts and novices alike can discover the latest trends, insights, and
        innovations shaping the digital landscape. From understanding blockchain fundamentals to navigating the
        intricate world of non-fungible tokens (NFTs), Oddity is your go-to platform for staying informed and inspired.
        In collaboration with Adidas Artificia, we bring you exclusive insights and perspectives at the forefront of
        digital evolution, bridging the gap between innovation and everyday impact. Join us on this transformative
        journey as we redefine the future of digital experiences together.
      </div>
    </div>
  );
});
