import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import classes from './Component6.module.css';

interface Props {
  className?: string;
}
/* @figmaId 884:70 */
export const Component6: FC<Props> = memo(function Component6(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.rectangle14}></div>
      <div className={classes.continue}>Continue</div>
    </div>
  );
});
